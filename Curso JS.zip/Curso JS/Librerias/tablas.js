$(document).ready(function() {
    $('#myTable').DataTable({
        "paging": true,      // Activar la paginación
        "searching": true,   // Activar la búsqueda
        "ordering": true,    // Activar el ordenamiento
        "info": true,        // Mostrar información de la tabla
        "pageLength": 5      // Número de filas por página
    });
});
