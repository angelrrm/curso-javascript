function updateModel() {
    const selectedModel = document.getElementById('modelSelect').value;
    alert('Has Seleccionado El Ferrari: ' + selectedModel + ', Buena Elección...');
}

// Lista de autos
const autos = [
    { marca: 'Ferrari', modelo: 'LaFerrari', año: 2013 },
    { marca: 'Ferrari', modelo: 'F40', año: 1987 },
    { marca: 'Ferrari', modelo: '488 Pista', año: 2018 },
];

// Función para filtrar autos por año
function filtrarPorAño(año) {
    return autos.filter(auto => auto.año === año);
}

// Evento para el botón
document.getElementById('consultarBtn').addEventListener('click', function () {
    const año = parseInt(document.getElementById('añoInput').value);
    const autosFiltrados = filtrarPorAño(año);
    const resultadoDiv = document.getElementById('resultado');

    if (autosFiltrados.length > 0) {
        resultadoDiv.innerHTML = `<h2>Autos del año ${año}:</h2>` +
            autosFiltrados.map(auto => `<p>${auto.marca} ${auto.modelo}</p>`).join('');
    } else {
        resultadoDiv.innerHTML = `<h2>No se encontraron autos del año ${año}.</h2>`;
    }
});
